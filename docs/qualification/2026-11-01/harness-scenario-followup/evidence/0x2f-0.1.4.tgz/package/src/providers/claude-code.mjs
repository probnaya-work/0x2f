// Claude Code execution provider — the boundary where Claude-specific
// behavior stops.
//
// Work talks to an ExecutionProvider, never to a specific agent CLI directly.
// The provider is responsible for translating a vendor's process into the
// normalized outcome shapes in ../core/lifecycle.mjs:
//
//   { status: "ready",    result }
//   { status: "needs_you", reason, blockedOn, result? }
//   { status: "failed",   error }
//
// A provider implements:
//
//   id: string                 e.g. "claude-code"
//   displayName: string
//   capabilities: {
//     supportsResume, supportsStructuredEvents,
//     supportsPermissionRequests, supportsSandbox, supportsStreaming
//   }
//   async start({ cwd, prompt, onEvent })                 -> outcome
//   async resume({ cwd, externalSessionId, grant, onEvent }) -> outcome
//
// `onEvent(event)` receives normalized progress events (run.started,
// progress, tool.started, tool.completed, needs_user). Consumers must not
// depend on vendor-specific event fields.
//
// Model vs harness: a provider is a harness (Claude Code, Codex, DeepSeek
// Harness, OpenCode). Which model runs inside is the provider's concern.
// Every concept in THIS file may be Claude-shaped; nothing outside this file
// may be.

import { spawn } from "node:child_process";
import { classifyResult } from "../core/lifecycle.mjs";

// ---------------------------------------------------------------------------
// Claude Code provider (native adapter — the boundary where Claude-specific
// behavior stops)
// ---------------------------------------------------------------------------
//
// Verified against Claude Code 2.1.241 (Aug 2026):
//
// SUPPORTED (used here):
//   - `claude -p --verbose --output-format stream-json "<prompt>"`
//     headless execution with structured, newline-delimited JSON events.
//   - `system/init` event carries `session_id` — the external session id.
//   - `result` event carries `permission_denials` (tool_name + full tool_input)
//     when a tool call needed permission that was not granted. Exit code is 0
//     and `is_error` is false in that case — a successful process, an
//     incomplete task. This is exactly the v0 dogfooding failure, now
//     detectable structurally instead of by parsing prose.
//   - `claude -p --resume <session-id> "<prompt>"` resumes the SAME session
//     (same session_id, full prior context).
//   - `--permission-mode acceptEdits` on a resumed run grants file-edit
//     permission so a previously blocked edit can proceed.
//
// NOT SUPPORTED RELIABLY (documented limitations, v0.2):
//   - `--allowedTools "Edit(<path>)"` combined with `--resume` in print mode
//     fails with "No deferred tool marker found in the resumed session" —
//     that path is built for interactive sessions paused at a permission
//     prompt, not headless denials. So the narrowest *reliable* grant on
//     resume is `--permission-mode acceptEdits` (per-session, file edits
//     only; Bash and other tools still need permission).
//   - Print-mode sessions only resume if the transcript was persisted to
//     ~/.claude/projects (default on). If the user's config disables
//     persistence, resume fails and Work reports it — it never pretends a
//     new session is the same session.

const ALLOW_PROMPT = `The user reviewed your last message and granted the requested permission.
Continue the task and complete the remaining work.

When you finish, return the same markdown sections as the original task:
## Result, ## Evidence, ## Changes, ## Verification, ## Needs human decision
(## Needs human decision uses the REQUIRED: yes / REQUIRED: no protocol.)`;

const REJECT_PROMPT = `The user reviewed your last message and rejected the requested change.
Do not attempt it again. Complete whatever part of the task you can
responsibly finish without it, or explain what remains blocked.

When you finish, return the same markdown sections as the original task:
## Result, ## Evidence, ## Changes, ## Verification, ## Needs human decision
(## Needs human decision uses the REQUIRED: yes / REQUIRED: no protocol.)`;

// Tools that actually mutate a file on disk. A Read, Grep, Glob or
// NotebookRead also carries a file_path but never changed anything — only
// these produce a file.changed event. This is the one place Claude's tool
// vocabulary is allowed to decide what counts as a change.
const MUTATING = new Set(["Edit", "MultiEdit", "Write", "NotebookEdit"]);

// Dogfooding found a FAILED task presenting a vendor 401 as if it were the
// task's own breakage — the same words a person would see if they ran
// `claude` in a terminal themselves, styled as an execution failure instead
// of the "go run one command outside 0x2F" instruction it actually is. The
// provider is the ONLY place vendor vocabulary is legal to read, so
// classification happens here, once, from Claude Code's own failure text —
// never in core or the UI. Only "auth" is classified today; anything else
// stays unclassified and renders exactly as before.
const AUTH_FAILURE_RE =
  /\b401\b|unauthenticated|not authenticated|re-?authenticate|invalid api key|invalid x-api-key|authentication_error|oauth[^.\n]*(expired|invalid|revoked)/i;

export function classifyClaudeFailure(text) {
  if (AUTH_FAILURE_RE.test(String(text ?? ""))) {
    // The one concrete, adapter-authored recovery step: shown verbatim by
    // the UI, never composed or guessed at by a general surface.
    return { kind: "auth", remedy: "claude /login" };
  }
  return null;
}

const CONTINUE_PROMPT = `Continue the task from where you left off.

When you finish, return the same markdown sections as the original task:
## Result, ## Evidence, ## Changes, ## Verification, ## Needs human decision
(## Needs human decision uses the REQUIRED: yes / REQUIRED: no protocol.)`;

export const claudeCodeProvider = {
  id: "claude-code",
  displayName: "Claude Code",
  capabilities: {
    supportsResume: true,
    supportsStructuredEvents: true,
    // This adapter emits file.changed itself for mutating tools only (see
    // MUTATING below) — a Read or Grep never produces one.
    supportsFileChanges: true,
    // tool.started already carries input.command for Bash calls, unchanged
    // by that fix — the COMMANDS dimension is honest today.
    supportsCommands: true,
    supportsPermissionRequests: true,
    supportsSandbox: false,
    supportsStreaming: true,
    // The written result is available the moment a run halts or completes,
    // not only at the very end — never gate the RESULT section on this.
    resultOnCompletion: false
  },

  async start({ cwd, prompt, onEvent = () => {} }) {
    const args = ["-p", "--verbose", "--output-format", "stream-json", prompt];
    return runClaude({ cwd, args, onEvent });
  },

  async resume({ cwd, externalSessionId, grant = "continue", onEvent = () => {} }) {
    const prompt =
      grant === "allow"
        ? ALLOW_PROMPT
        : grant === "reject"
          ? REJECT_PROMPT
          : CONTINUE_PROMPT;

    const args = ["-p", "--verbose", "--output-format", "stream-json"];
    if (!externalSessionId) {
      throw new Error("No external session id — this task cannot be resumed.");
    }
    args.push("--resume", externalSessionId);
    if (grant === "allow") {
      // See "NOT SUPPORTED RELIABLY" above: acceptEdits is the narrowest
      // grant that works for headless resume in current Claude Code.
      args.push("--permission-mode", "acceptEdits");
    }
    args.push(prompt);
    return runClaude({ cwd, args, onEvent, resuming: true });
  }
};

// ---------------------------------------------------------------------------
// Stream handling
// ---------------------------------------------------------------------------

// Injectable for tests and non-PATH installs; defaults to `claude` on PATH.
export function claudeBin() {
  return process.env.CLAUDE_BIN ?? "claude";
}

// A failed invocation -> a normalized failed outcome. When the failure
// happens on a RESUME, the run is classified kind "resume" (unless it is a
// more specific auth failure): the human's ALLOW was recorded, but Claude
// Code could not continue the session — print-mode session resume is not
// reliably supported by the vendor CLI (documented limitation) — so the run
// must fail HONESTLY instead of pretending the permission was successfully
// granted and the work continued. This is structural (the invocation was a
// resume), never a match on a vendor error string.
function failedOutcome(error, resuming) {
  const failure = classifyClaudeFailure(error);
  if (!resuming || failure) {
    return { status: "failed", error, ...(failure ? { failure } : {}) };
  }
  return {
    status: "failed",
    error:
      `Claude Code could not resume the session (${error}). ` +
      `The permission was recorded, but print-mode session resume is not reliably ` +
      `supported by the installed Claude Code CLI, so the work could not be ` +
      `continued in place. Rerun the task or close it.`,
    failure: { kind: "resume" }
  };
}

function runClaude({ cwd, args, onEvent, resuming = false }) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(claudeBin(), args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
    } catch (error) {
      reject(error);
      return;
    }

    let buffer = "";
    let stderr = "";
    let sessionId = null;
    let resultEvent = null;
    let sawEvent = false;

    child.stdout.on("data", chunk => {
      buffer += chunk.toString();
      let nl;
      while ((nl = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (!line) continue;
        let event;
        try {
          event = JSON.parse(line);
        } catch {
          continue; // not JSON — ignore stray output
        }
        sawEvent = true;
        handleEvent(event);
      }
    });

    child.stderr.on("data", chunk => {
      stderr += chunk.toString();
    });

    child.on("error", error => {
      reject(new Error(`Could not start claude: ${error.message}`));
    });

    child.on("close", code => {
      if (resultEvent) {
        try {
          resolve(normalizeOutcome(resultEvent, { sessionId }));
        } catch (error) {
          reject(error);
        }
      } else if (code !== 0) {
        const error =
          stderr.trim() ||
          `claude exited with code ${code} before producing a result.`;
        resolve(failedOutcome(error, resuming));
      } else {
        const error = sawEvent
          ? "claude exited without a result event."
          : "claude produced no output. Is the Claude Code CLI installed and authenticated?";
        resolve(failedOutcome(error, resuming));
      }
    });

    function handleEvent(event) {
      if (event.type === "system" && event.subtype === "init") {
        sessionId = event.session_id ?? null;
        onEvent({ type: "run.started", sessionId });
      } else if (event.type === "system" && event.subtype === "permission_denied") {
        onEvent({
          type: "needs_user",
          reason: "permission",
          detail: { tool: event.tool_name, message: event.message }
        });
      } else if (event.type === "assistant") {
        for (const block of event.message?.content ?? []) {
          if (block.type === "tool_use") {
            onEvent({ type: "tool.started", name: block.name, input: block.input });
            if (MUTATING.has(block.name) && typeof block.input?.file_path === "string") {
              onEvent({ type: "file.changed", path: block.input.file_path });
            }
          } else if (block.type === "text" && block.text) {
            onEvent({ type: "progress", text: block.text });
          }
        }
      } else if (event.type === "user") {
        for (const block of event.message?.content ?? []) {
          if (block.type === "tool_result") {
            onEvent({
              type: "tool.completed",
              isError: block.is_error === true
            });
          }
        }
      } else if (event.type === "result") {
        resultEvent = event;
      }
    }
  });
}

// Parse newline-delimited stream-json output (exported for tests).
export function parseStreamJson(text) {
  const events = [];
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      events.push(JSON.parse(trimmed));
    } catch {
      // ignore non-JSON lines
    }
  }
  return events;
}

// The vendor `result` event -> normalized outcome. Pure and testable.
export function normalizeOutcome(result, { sessionId = null } = {}) {
  const denials = Array.isArray(result.permission_denials)
    ? result.permission_denials
    : [];

  // A successful process that ended blocked on permission is NEEDS YOU,
  // never READY. Check denials before is_error: a run that "failed" because
  // it was blocked on permission is still a permission block.
  if (denials.length > 0) {
    const first = denials[0];
    const input = first.tool_input ?? {};
    return {
      status: "needs_you",
      reason: "permission",
      externalSessionId: result.session_id ?? sessionId,
      result: typeof result.result === "string" ? result.result : "",
      blockedOn: {
        type: "permission",
        tool: first.tool_name,
        file: typeof input.file_path === "string" ? input.file_path : null,
        plannedChange: describeChange(first.tool_name, input),
        raw: first
      }
    };
  }

  if (result.is_error === true) {
    const errors = Array.isArray(result.errors)
      ? result.errors.join("; ")
      : "";
    const error =
      errors ||
      (typeof result.result === "string" && result.result.trim()
        ? result.result
        : "Claude Code reported an execution error.");
    const failure = classifyClaudeFailure(error);
    return {
      status: "failed",
      externalSessionId: result.session_id ?? sessionId,
      error,
      ...(failure ? { failure } : {})
    };
  }

  const text = typeof result.result === "string" ? result.result : "";
  const classified = classifyResult(text);
  if (classified.status === "needs_you") {
    return {
      status: "needs_you",
      reason: "decision",
      externalSessionId: result.session_id ?? sessionId,
      result: text,
      blockedOn: classified.blockedOn
    };
  }
  if (classified.status === "failed") {
    return {
      status: "failed",
      externalSessionId: result.session_id ?? sessionId,
      error: classified.error,
      failure: classified.failure
    };
  }
  return {
    status: "ready",
    externalSessionId: result.session_id ?? sessionId,
    result: text
  };
}

function snippet(value, max = 100) {
  const s = String(value).replace(/\s+/g, " ").trim();
  return s.length > max ? s.slice(0, max) + "…" : s;
}

function describeChange(tool, input) {
  if (tool === "Edit" && input.old_string != null && input.new_string != null) {
    return `${snippet(input.old_string, 80)}  →  ${snippet(input.new_string, 80)}`;
  }
  if (typeof input.file_path === "string") {
    return `file: ${input.file_path}`;
  }
  if (typeof input.command === "string") {
    return `command: ${snippet(input.command)}`;
  }
  return snippet(JSON.stringify(input));
}

// Work's prompt asks the agent to end with a `## Needs human decision`
// section. That parsing is a Work convention, so it lives in core and is
// shared by every provider; this module only re-exports it for backward
// compatibility.
export { decisionSection, hasHumanDecision } from "../core/lifecycle.mjs";
